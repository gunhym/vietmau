package nitro.mavenproject3;

/**
 *
 * @author Admin
 */
public class ProductionManager {

    public DB getFile() {
        return file;
    }

    public void setFile(DB file) {
        this.file = file;
    }
    private DB file;
    
    public ProductionManager() {
        file = new DB();   
        // doan nay , phai de file = new DB vi t can khoi tao 1 doi tuong DB de goi phuong thuc write ben duoi , 
        // neu khong them gi ca thi de khong constructor thì n k khởi tạo đối tượng file 
    }
    
    public void addProduct(Production sp) {
        if (sp instanceof Book) {
            Book s = (Book) sp;
            DB.listBook.add(s);
        } else if (sp instanceof Disc) {
            Disc dp = (Disc) sp;
            DB.listDisc.add(dp);
        } 
        file.writeProductToDB();
        file.writeProductToFile();
    }
}
