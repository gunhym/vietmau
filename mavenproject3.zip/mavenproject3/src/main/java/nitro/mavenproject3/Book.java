package nitro.mavenproject3;

/**
 *
 * @author Admin
 */
public class Book extends Production {

    private String publisher;
    private String category;
    private String author;

    public Book(String publisher, String category, String author, String code, String name, int buyPrice, int sellPrice, String producer, int amount) {
        super(code, name, buyPrice, sellPrice, producer, amount);
        this.publisher = publisher;
        this.category = category;
        this.author = author;
    }

 

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

}
