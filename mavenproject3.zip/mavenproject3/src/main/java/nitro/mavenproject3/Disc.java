package nitro.mavenproject3;

/**
 *
 * @author Admin
 */
public class Disc extends Production {

    private String Actor;
    private String Director;
    private String Producer;

    public String getActor() {
        return Actor;
    }

    public void setActor(String Actor) {
        this.Actor = Actor;
    }

    public String getDirector() {
        return Director;
    }

    public void setDirector(String Director) {
        this.Director = Director;
    }

    public String getProducer() {
        return Producer;
    }

    public void setProducer(String Producer) {
        this.Producer = Producer;
    }

    public Disc(String Actor, String Director, String Producer, String code, String name, int buyPrice, int sellPrice, String producer, int amount) {
        super(code, name, buyPrice, sellPrice, producer, amount);
        this.Actor = Actor;
        this.Director = Director;
        this.Producer = Producer;
    }

}
