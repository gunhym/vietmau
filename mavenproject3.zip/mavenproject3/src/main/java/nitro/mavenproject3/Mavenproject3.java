
package nitro.mavenproject3;

/**
 *
 * @author Admin
 */
public class Mavenproject3 {

    public static void main(String[] args) {
        Book a = new Book("abc", "abc", "abc", "abc", "abc", 100, 1000, "abc", 1);
        ProductionManager b = new ProductionManager();
        b.addProduct(a);
    }
}
