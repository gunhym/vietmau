package nitro.mavenproject3;

/**
 *
 * @author Admin
 */

import java.util.ArrayList;
public class DB {
    public static ArrayList<Book> listBook = new ArrayList<>();
    public static ArrayList<Disc> listDisc = new ArrayList<>();
    
    private void getlist_Product() {
       // doan nay lay du lieu trong database của book và disc
      // sau do them vao trong listBook và listDisc
      // phai clear du lieu trong listBook,listDisc hiện tại để lấy dữ liệu từ database
      // nên nếu t để static ở trong productionManager và k thêm file new DB thì n sẽ bị bug :v , lúc t viết thử lần đầu thì t nghĩ là phải khởi tạo thì ms đc
      // nma giờ t cx đang chưa rõ là do đâu nữa
        System.out.println("get list product success");
    }
    public ArrayList<Book> getlist_Book() {
        return listBook;
    }
    public ArrayList<Disc> getlist_Disc() {
        return listDisc;
    }
    public void writeProductToDB() {
        // doan nay dua du lieu listBook moi va listDisc moi len Database
        System.out.println("dua du lieu vao mySQL thanh cong");
    }
    public void writeProductToFile() {
        // Doan nay dua du lieu listBook va listDisc vao file excel
        System.out.println("dua du lieu vao File thanh cong");
    }
    
    
   

}
